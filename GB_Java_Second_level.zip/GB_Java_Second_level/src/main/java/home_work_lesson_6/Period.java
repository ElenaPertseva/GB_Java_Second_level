package home_work_lesson_6;

public enum Period {
    NOW, FIVE_DAYS, DB
}
