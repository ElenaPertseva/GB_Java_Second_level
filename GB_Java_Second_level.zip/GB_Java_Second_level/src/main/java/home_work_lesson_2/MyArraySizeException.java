package home_work_lesson_2;

public class MyArraySizeException extends Exception {
    public MyArraySizeException() {
        super("Размер массива не корректный!");
    }
}
