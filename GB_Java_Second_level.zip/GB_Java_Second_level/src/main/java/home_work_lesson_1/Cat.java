package home_work_lesson_1;

public class Cat extends Animal {
    public Cat(String name){
        super("Кошка", "Муся", 100,2 );
    }


    @Override
    public void jump(int height) {

    }
}
