package home_work_lesson_1.obstacles;

import home_work_lesson_1.Competitor;

public class Cross extends Obstacle {
    private int  distance;

    public Cross(int distance){
        this.distance = distance;
    }

    @Override
    public void doIt(Competitor competitor) {

    }
}
