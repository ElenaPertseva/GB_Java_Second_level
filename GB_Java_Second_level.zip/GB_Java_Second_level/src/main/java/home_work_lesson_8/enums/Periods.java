package home_work_lesson_8.enums;

public enum Periods {
    NOW,
    FIVE_DAYS,
    CUSTOM
}
