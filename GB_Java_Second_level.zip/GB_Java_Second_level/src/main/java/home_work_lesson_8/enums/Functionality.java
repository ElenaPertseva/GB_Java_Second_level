package home_work_lesson_8.enums;

public enum Functionality {
    GET_CURRENT_WEATHER,
    GET_WEATHER_IN_NEXT_5_DAYS
}
